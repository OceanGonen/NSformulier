>[!NOTE] Dit is een schoolproject!


Maandag 17/2
Ik ben begonnen met het opzetten van de basisstructuur van het erfbelastingformulier. Ik heb de HTML-structuur uitgewerkt met een duidelijke hiërarchie van <form>, <fieldset> en <legend> elementen, zodat het formulier logisch en semantisch correct is opgebouwd. Hierbij heb ik de verschillende onderdelen gescheiden in secties zoals gegevens van de overledene, partner, nabestaanden, testament en gemachtigde. Ook heb ik alvast validatie-attributen toegevoegd zoals required, pattern en type="email" om basisvalidatie via HTML mogelijk te maken.

Doel: Een duidelijke en semantisch correcte formulierstructuur opzetten die overzichtelijk en toegankelijk is.

Behaald: Volledige HTML-structuur opgezet met logische groepering via fieldsets en legends. Basisvalidatie toegevoegd via HTML-attributen (required, pattern, input types).

Dinsdag 18/2
Deze dag heb ik me gericht op styling en interactieve logica met CSS. Ik heb een visuele stijl opgezet in NS-huisstijl met CSS-variabelen (:root) voor kleuren, zodat het ontwerp consistent en makkelijk aanpasbaar blijft. Daarnaast heb ik custom radio buttons gemaakt waarbij de standaard radio-input verborgen is en de bijbehorende labels visueel veranderen met :has() wanneer een optie is geselecteerd. Ook heb ik conditionele velden visueel uitgeschakeld met behulp van de :has() selector en pointer-events: none, zodat vervolgvragen automatisch vervagen wanneer een gebruiker “Nee” selecteert. Verder heb ik formulierfeedback toegevoegd via input:user-invalid om foutieve invoer direct visueel te markeren.

Doel: Het formulier visueel aantrekkelijk maken en interactieve afhankelijkheden tussen vragen creëren zonder JavaScript.

Behaald: NS-styling geïmplementeerd met CSS-variabelen. Interactieve radio-buttons gemaakt met :has(). Conditionele velden dynamisch uitgeschakeld via pure CSS. Visuele validatiefeedback toegevoegd met :user-invalid.

Bronnen:

MDN – :user-invalid pseudo-class

MDN – CSS :has()

MDN – HTML form validation




Week 4: (17 feb - 18 feb)
Focus: Semantiek, CSS en Gebruikersinteractie


Deze week van het project stond volledig in het teken van het vertalen van de complexe, papieren erfbelastingaangifte naar een robuuste webpagina. In plaats van direct met JavaScript aan de slag te gaan, koos ik voor een aanpak waarbij de focus eerst lag op een sterke HTML-structuur en slimme CSS-oplossingen.

Ik begon de week met het uittekenen van de semantische hiërarchie. In eerste instantie was de verleiding groot om simpelweg invoervelden onder elkaar te plaatsen, maar ik merkte al snel dat de logica dan verloren ging. Achteraf was de keuze voor een gelaagde structuur met <form>, <fieldset> en <legend> cruciaal; het dwong me om de data te groeperen in logische secties zoals de overledene, de nabestaanden en de gemachtigde. Terwijl ik deze structuur opzette, liep ik direct tegen de grenzen van HTML-validatie aan. Vooral het BSN-veld bleek een technisch struikelblok; hoewel de basisvalidatie met required snel stond, was het sluitend krijgen van de Regex-patronen voor een correcte invoer een proces van vallen en opstaan.

Zodra het fundament stond, verschoof de focus naar de visuele en  interactieve flow. Het doel was om een "slim" formulier te bouwen dat mee beweegt met de gebruiker zonder zware scripts. De grootste technische doorbraak was hierbij de implementatie van de :has() selector. Aanvankelijk worstelde ik met de vraag hoe ik vervolgvragen kon verbergen zonder de lay-out te laten verspringen. Door :has() te combineren met opacity en pointer-events: none ontstond er een natuurlijke "Progressive Disclosure": velden die niet relevant zijn voor een specifieke situatie, vervagen nu vloeiend op de achtergrond. Ook de radio-buttons vergden extra aandacht; de standaard browser-styling voelde verouderd aan, waardoor ik ervoor koos de inputs visueel te verbergen en de labels om te bouwen tot grote, klikbare containers.





Woensdag 24/02
Doel: Het formulier responsive maken met grid en dynamisch maken met progressive disclosure en validatiefouten door middel van Javascript.

Eerst bleven onzichtbare velden het verzenden blokkeren omdat ze nog op required stonden. Ook bleven velden rood kleuren als de gebruiker zich bedacht en een vraag weer verborg.
Met js heb ik er voor gezorgd dat zodra een gebruiker "Ja" klikt, worden de vervolgvragen niet alleen zichtbaar, maar worden ze via data-required ook echt verplicht gemaakt.

<img width="473" height="78" alt="image" src="https://github.com/user-attachments/assets/ea530144-fb72-4e5f-8a09-9a6e400721b3" />

Met flex grid en media queries heb ik de lay-out nu mooi responsive voor grote schermen. 


Maandag 02/03
Doel: De gebruikerservaring verbeteren met responsive formattering en het oplossen van complexe validatie-issues bij dynamische velden.

Behaald:

Input Formatting (UX): Een script toegevoegd dat voorletters tijdens het typen opschoont, omzet naar hoofdletters en automatisch spaties toevoegt. Dit voorkomt dat gebruikers zelf punten of spaties moeten invoeren en zorgt voor een uniforme dataset. Ook postcodes.
<img width="775" height="299" alt="image" src="https://github.com/user-attachments/assets/e5f2ce8a-427e-4d0e-9a8a-e9bc67245fd9" />


Exclusieve Velden: Logica gebouwd voor de identificatie van de gemachtigde. Zodra er in één van de drie opties (BSN, Beconnummer of Protocolnummer) wordt getypt, worden de andere velden direct disabled en visueel minder zichtbaar gemaakt. 

Sectie-validatie: Een systeem ontwikkeld dat per fieldset controleert of alle verplichte velden zijn ingevuld. Bij een volledige sectie verschijnt er een groen vinkje met een popIn animatie.

Technische uitdagingen & Leerpunten:

Dynamische Validatie & Radio Buttons: Ik ben tegen een specifiek probleem aangelopen bij de required status van radio buttons in verborgen secties. Hoewel tekstvelden zich goed laten sturen via JS, bleek de browser-validatie bij radio buttons soms 'hangen'.  

Het "Not Focusable" probleem: Wanneer een fielset wordt verborgen, moet de required status er direct vanaf, anders blokkeert de browser het verzenden met de foutmelding "An invalid form control is not focusable".

Conclusie: Het dynamisch verplicht maken van radio buttons via JavaScript is complexer dan bij tekstvelden, omdat de browser de hele groep (alle radio's met dezelfde naam) als één geheel ziet. Ik heb dit deels opgelost door de verplichting programmatisch te verwijderen zodra een fieldset onzichtbaar wordt, maar de native browser-feedback blijft bij radio buttons minder stabiel dan gewenst.

Bronnen:

MDN - Constraint validation API

StackOverflow - HTML5 validation 'An invalid form control is not focusable'

JavaScript.info - Forms: event and method submit



Week 5: (24 feb - 02 mar)

Deze week van het project verschoof de focus naar de gebruikerservaring en het oplossen van de complexere interactie-puzzels die ontstonden door de dynamiek van het formulier.

Het grootste struikelblok was aanvankelijk de "Progressive Disclosure". Achteraf bleek dat het simpelweg tonen en verbergen van velden niet genoeg was; onzichtbare velden bleven de verzending blokkeren omdat ze op de achtergrond nog op required stonden. Dit leidde tot de beruchte browserfout "An invalid form control is not focusable". Ik heb dit opgelost door een systeem te bouwen waarbij velden pas echt verplicht worden (via data-required) op het moment dat ze zichtbaar worden. Dit zorgde er ook voor dat foutmeldingen netjes werden opgeschoond wanneer een gebruiker zich bedacht en een sectie weer sloot. Vooral bij radio buttons bleek dit complex, omdat de browser een groep radio-knoppen als één geheel ziet, wat de validatie-status soms liet "hangen".

Tegelijkertijd heb ik gewerkt aan de visuele rust en datakwaliteit. Ik heb scripts toegevoegd voor automatische input-formatting. Tijdens het typen van voorletters worden tekens nu direct opgeschoond en voorzien van spaties, wat niet alleen prettiger werkt voor de gebruiker, maar ook een uniforme dataset oplevert. Voor de gemachtigde-sectie heb ik een "exclusiviteits-logica" gebouwd: zodra een gebruiker begint te typen in één van de drie identificatiemogelijkheden, worden de andere twee direct gedeactiveerd. Dit voorkomt verwarring over welke gegevens prioriteit hebben.

Om de gebruiker een gevoel van progressie te geven, heb ik een sectie-validatiesysteem ontwikkeld. Per fieldset wordt nu gecontroleerd of alles correct is ingevuld, waarna een groen vinkje met een subtiele animatie bevestigt dat een onderdeel afgerond is. Door deze logica te combineren met een responsive grid-layout, voelt het formulier nu op elk schermformaat ondersteunend aan.

Technische Hoogtepunten
Dynamische Constraint Validation: De implementatie van een script dat de required-status met de zichtbaarheid beheert. Dit loste het "Not Focusable"-probleem definitief op en maakte het formulier verzendbaar in alle scenario's.

Real-time Input Sanitization: Het bouwen van een formatterings-engine die voorletters en postcodes tijdens de interactie corrigeert. Dit vermindert de cognitieve belasting omdat de gebruiker zich minder zorgen hoeft te maken over interpunctie of hoofdletters.




Maandag 16/03

Ik heb de PDF-export toegevoegd voor printen. De grootste uitdaging is het overschrijven van de :has()-selectors die op het scherm velden grijs maken. Door de print-media query agressief in te stellen, wordt het formulier op papier nu scanbaar. Ook is de layout gedwongen naar een verticale 'stack', wat veel natuurlijker leest op een A4-tje, terwijl de adresvelden horizontaal blijven voor logische groepering.

Doel: Een professioneel, printbaar document genereren dat alle conditionele logica negeert voor handmatige invulling.
Behaald: CSS Print-grid voltooid. Alle interactieve 'JS-only' elementen verborgen. Blanco pen-vriendelijke radio buttons ontworpen.